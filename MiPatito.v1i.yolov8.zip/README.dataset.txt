# MiPatito > 2025-04-21 12:10pm
https://universe.roboflow.com/mipatito/mipatito

Provided by a Roboflow user
License: CC BY 4.0

